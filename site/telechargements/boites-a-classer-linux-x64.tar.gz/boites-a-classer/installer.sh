#!/bin/sh
# Installe Boîtes à classer pour l'utilisateur courant (menu des applications).
set -eu
cd "$(dirname "$0")"
mkdir -p "$HOME/.local/share/boites-a-classer" "$HOME/.local/share/applications"
cp boites-a-classer icone.png "$HOME/.local/share/boites-a-classer/"
cat > "$HOME/.local/share/applications/boites-a-classer.desktop" <<FIN
[Desktop Entry]
Type=Application
Name=Boîtes à classer
Comment=Classer les êtres vivants dans des boîtes emboîtées
Exec=$HOME/.local/share/boites-a-classer/boites-a-classer
Icon=$HOME/.local/share/boites-a-classer/icone.png
Categories=Education;Science;
FIN
echo "Installé : cherchez « Boîtes à classer » dans le menu des applications."
